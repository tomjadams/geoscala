/*                     __                                               *\
**     ________ ___   / /  ___     Scala API                            **
**    / __/ __// _ | / /  / _ |    (c) 2002-2009, LAMP/EPFL             **
**  __\ \/ /__/ __ |/ /__/ __ |    http://scala-lang.org/               **
** /____/\___/_/ |_/____/_/ | |                                         **
**                          |/                                          **
\*                                                                      */

// $Id: unsealed.scala 16894 2009-01-13 13:09:41Z cunei $


package scala

/** @deprecated   use <a href="unchecked.html">
 *  <code>@unchecked</code></a> instead.
 */
@deprecated class unsealed extends Annotation
